package com.telinova.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int BG_PICK = 21;
    private static final int TEAL = Color.rgb(84, 214, 200);

    private static class Entry {
        String label;
        String pkg;
        Drawable icon;
    }

    private SharedPreferences prefs;
    private LinearLayout root, content;
    private TextView clock;
    private boolean focusMode, lightMode, resumed, appsDirty = true;
    private String wallpaperUri;
    private Bitmap wallpaperBitmap;
    private List<Entry> entries;
    private BroadcastReceiver pkgReceiver;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            updateClock();
            handler.postDelayed(this, 30000);
        }
    };

    // ---------- الألوان (تتبع المظهر الحالي) ----------
    private boolean light() { return lightMode && wallpaperBitmap == null; }
    private int bgColor() { return light() ? 0xffeaf0f6 : Color.rgb(7, 17, 31); }
    private int cardColor() { return light() ? 0xffffffff : Color.rgb(20, 38, 58); }
    private int focusColor() { return light() ? 0xffcdeeea : 0xff20535a; }
    private int textMain() { return light() ? 0xff0b1b2b : Color.rgb(245, 248, 252); }
    private int textSub() { return light() ? 0xff4a5f73 : 0xffa9bdcf; }
    private int accent() { return light() ? 0xff0b7f74 : TEAL; }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("telinova", MODE_PRIVATE);
        wallpaperUri = prefs.getString("wallpaper", null);
        focusMode = prefs.getBoolean("focusMode", false);
        lightMode = prefs.getBoolean("lightMode", false);

        pkgReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                appsDirty = true;
                if (resumed) renderApps();
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);

        rebuild();
        if (wallpaperUri != null) {
            loadWallpaperAsync(wallpaperUri, new Runnable() { @Override public void run() { rebuild(); } });
        }
    }

    @Override protected void onResume() {
        super.onResume();
        resumed = true;
        handler.removeCallbacks(tick);
        handler.post(tick);
        if (appsDirty) renderApps();
    }

    @Override protected void onPause() {
        resumed = false;
        handler.removeCallbacks(tick);
        super.onPause();
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(pkgReceiver); } catch (Exception ignored) {}
        super.onDestroy();
    }

    // الشاشة الرئيسية لا تُغلق بزر الرجوع
    @Override public void onBackPressed() { }

    private void rebuild() {
        buildUI();
        renderApps();
        updateClock();
    }

    // ---------- عناصر الواجهة ----------
    private GradientDrawable shape(int color, int radiusDp, boolean focused) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (focused) d.setStroke(dp(2), accent());
        else d.setStroke(dp(1), Color.argb(30, 255, 255, 255));
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(dp(4), dp(3), dp(4), dp(3));
        return t;
    }

    private void addControl(LinearLayout row, String label, final Runnable action) {
        final Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(textMain());
        b.setFocusable(true);
        b.setBackground(shape(cardColor(), 12, false));
        b.setPadding(dp(18), dp(6), dp(18), dp(6));
        b.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean hasFocus) {
                v.setBackground(shape(hasFocus ? focusColor() : cardColor(), 12, hasFocus));
            }
        });
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { action.run(); }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(46));
        lp.setMarginEnd(dp(10));
        row.addView(b, lp);
    }

    private void buildUI() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(bgColor());
        if (wallpaperBitmap != null) {
            ImageView bg = new ImageView(this);
            bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
            bg.setImageBitmap(wallpaperBitmap);
            frame.addView(bg, new FrameLayout.LayoutParams(-1, -1));
            View scrim = new View(this);
            scrim.setBackgroundColor(0x99000000);
            frame.addView(scrim, new FrameLayout.LayoutParams(-1, -1));
        }
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(40), dp(24), dp(40), dp(16));
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView logo = text("T", 28, Color.rgb(7, 17, 31), true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(shape(TEAL, 14, false));
        top.addView(logo, new LinearLayout.LayoutParams(dp(56), dp(56)));
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPaddingRelative(dp(14), 0, 0, 0);
        brand.addView(text("تيلينوفا TV", 26, textMain(), true));
        brand.addView(text("واجهة تلفازك، بطريقتك", 13, textSub(), false));
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout status = new LinearLayout(this);
        status.setOrientation(LinearLayout.VERTICAL);
        status.setGravity(Gravity.END);
        clock = text("--:--", 22, textMain(), true);
        status.addView(clock);
        status.addView(text("☀  الطقس: يتطلب اتصال خدمة الطقس", 12, textSub(), false));
        top.addView(status);
        root.addView(top);

        TextView heading = text("كل ما تحب، في مكان واحد.", 28, textMain(), true);
        heading.setPadding(dp(4), dp(18), dp(4), dp(2));
        root.addView(heading);
        root.addView(text("تطبيقاتك المثبتة على التلفاز، بما فيها تطبيقات الفيديو والصوتيات.", 15, textSub(), false));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setPadding(0, dp(10), 0, dp(6));
        addControl(controls, "الإعدادات", new Runnable() { @Override public void run() { openSettings(); } });
        addControl(controls, "تغيير الخلفية", new Runnable() { @Override public void run() { pickWallpaper(); } });
        if (wallpaperUri != null) {
            addControl(controls, "إزالة الخلفية", new Runnable() { @Override public void run() { removeWallpaper(); } });
        }
        addControl(controls, "وضع التركيز", new Runnable() { @Override public void run() { toggleFocusMode(); } });
        addControl(controls, "المظهر", new Runnable() { @Override public void run() { toggleTheme(); } });
        addControl(controls, "تحديث الطقس", new Runnable() {
            @Override public void run() {
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("حالة الطقس")
                    .setMessage("عرض الطقس الحقيقي يحتاج إلى اتصال بالإنترنت ومصدر بيانات طقس. لم يتم تضمين مفتاح خدمة خارجي في هذا الإصدار.")
                    .setPositiveButton("حسناً", null).show();
            }
        });
        root.addView(controls);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(2), 0, dp(8));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    // ---------- الإجراءات ----------
    private void openSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح الإعدادات", Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleFocusMode() {
        focusMode = !focusMode;
        prefs.edit().putBoolean("focusMode", focusMode).apply();
        Toast.makeText(this, focusMode ? "تم تشغيل وضع التركيز" : "تم إيقاف وضع التركيز", Toast.LENGTH_SHORT).show();
        renderApps();
    }

    private void toggleTheme() {
        if (wallpaperBitmap != null) {
            Toast.makeText(this, "أزل صورة الخلفية أولاً لاستخدام المظهر الفاتح", Toast.LENGTH_LONG).show();
            return;
        }
        lightMode = !lightMode;
        prefs.edit().putBoolean("lightMode", lightMode).apply();
        rebuild();
    }

    private void pickWallpaper() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        try {
            startActivityForResult(i, BG_PICK);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "اختيار الصور غير متاح على هذا الجهاز", Toast.LENGTH_LONG).show();
        }
    }

    private void removeWallpaper() {
        wallpaperUri = null;
        wallpaperBitmap = null;
        prefs.edit().remove("wallpaper").apply();
        rebuild();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == BG_PICK && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            final String chosen = uri.toString();
            loadWallpaperAsync(chosen, new Runnable() {
                @Override public void run() {
                    if (wallpaperBitmap != null) {
                        wallpaperUri = chosen;
                        prefs.edit().putString("wallpaper", chosen).apply();
                    } else {
                        Toast.makeText(MainActivity.this, "تعذر تحميل الصورة", Toast.LENGTH_LONG).show();
                    }
                    rebuild();
                }
            });
        }
    }

    // تحميل الصورة بحجم مناسب للشاشة وخارج الخيط الرئيسي
    private void loadWallpaperAsync(final String uriStr, final Runnable done) {
        new Thread(new Runnable() {
            @Override public void run() {
                Bitmap bmp = null;
                try {
                    Uri uri = Uri.parse(uriStr);
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    InputStream in = getContentResolver().openInputStream(uri);
                    try { BitmapFactory.decodeStream(in, null, o); } finally { if (in != null) in.close(); }
                    int sample = 1;
                    while (o.outWidth / (sample * 2) >= 1920 && o.outHeight / (sample * 2) >= 1080) sample *= 2;
                    o.inJustDecodeBounds = false;
                    o.inSampleSize = sample;
                    InputStream in2 = getContentResolver().openInputStream(uri);
                    try { bmp = BitmapFactory.decodeStream(in2, null, o); } finally { if (in2 != null) in2.close(); }
                } catch (Exception e) {
                    bmp = null;
                } catch (OutOfMemoryError e) {
                    bmp = null;
                }
                final Bitmap result = bmp;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (isFinishing()) return;
                        wallpaperBitmap = result;
                        done.run();
                    }
                });
            }
        }).start();
    }

    private void updateClock() {
        if (clock == null) return;
        Date now = new Date();
        clock.setText(DateFormat.getTimeInstance(DateFormat.SHORT, Locale.getDefault()).format(now)
            + "   " + DateFormat.getDateInstance(DateFormat.MEDIUM, Locale.getDefault()).format(now));
    }

    // ---------- التطبيقات ----------
    private Set<String> favorites() {
        return new HashSet<String>(prefs.getStringSet("favorites", new HashSet<String>()));
    }

    private void saveFavorites(Set<String> set) {
        prefs.edit().putStringSet("favorites", new HashSet<String>(set)).apply();
    }

    private List<Entry> loadEntries() {
        PackageManager pm = getPackageManager();
        List<Entry> list = new ArrayList<Entry>();
        for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
            if (getPackageName().equals(ai.packageName)) continue;
            if (pm.getLaunchIntentForPackage(ai.packageName) == null) continue;
            Entry e = new Entry();
            e.pkg = ai.packageName;
            e.label = String.valueOf(pm.getApplicationLabel(ai));
            try { e.icon = pm.getApplicationIcon(ai); } catch (Exception ignored) {}
            list.add(e);
        }
        Collections.sort(list, new Comparator<Entry>() {
            @Override public int compare(Entry a, Entry b) { return a.label.compareToIgnoreCase(b.label); }
        });
        return list;
    }

    private void addSection(String title) {
        TextView h = text(title, 20, accent(), true);
        h.setPadding(dp(4), dp(14), dp(4), dp(6));
        content.addView(h);
    }

    private GridLayout newGrid() {
        GridLayout g = new GridLayout(this);
        g.setColumnCount(focusMode ? 3 : 5);
        content.addView(g, new LinearLayout.LayoutParams(-1, -2));
        return g;
    }

    private void renderApps() {
        if (content == null) return;
        // حفظ موضع التركيز كي لا يضيع عند إعادة الرسم
        String focusKey = null;
        View cur = getCurrentFocus();
        if (cur != null && cur.getTag() instanceof String) focusKey = (String) cur.getTag();

        if (appsDirty || entries == null) {
            entries = loadEntries();
            appsDirty = false;
        }
        content.removeAllViews();
        Set<String> fav = favorites();
        List<View> tiles = new ArrayList<View>();

        addSection("المفضلة ★");
        GridLayout favGrid = newGrid();
        int favCount = 0;
        for (Entry e : entries) {
            if (fav.contains(e.pkg)) { tiles.add(addAppTile(favGrid, e, "f:")); favCount++; }
        }
        if (favCount == 0) {
            content.addView(text("اضغط مطولاً على أي تطبيق لإضافته إلى المفضلة.", 14, textSub(), false));
        }
        addSection("كل التطبيقات");
        GridLayout grid = newGrid();
        for (Entry e : entries) tiles.add(addAppTile(grid, e, "a:"));

        if (focusKey != null) {
            String alt = "a:" + focusKey.substring(2);
            View target = null, fallback = null;
            for (View t : tiles) {
                if (focusKey.equals(t.getTag())) target = t;
                else if (alt.equals(t.getTag())) fallback = t;
            }
            if (target == null) target = fallback;
            if (target != null) target.requestFocus();
        }
    }

    private View addAppTile(GridLayout grid, final Entry e, String tagPrefix) {
        final PackageManager pm = getPackageManager();
        final TextView label = text(e.label, focusMode ? 17 : 14, textMain(), true);
        final LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(dp(6), dp(8), dp(6), dp(6));
        tile.setBackground(shape(cardColor(), 14, false));
        tile.setFocusable(true);
        tile.setClickable(true);
        tile.setContentDescription(e.label);
        tile.setTag(tagPrefix + e.pkg);

        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = 0;
        lp.height = dp(focusMode ? 150 : 118);
        lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        tile.setLayoutParams(lp);

        ImageView icon = new ImageView(this);
        if (e.icon != null) icon.setImageDrawable(e.icon);
        int size = dp(focusMode ? 72 : 52);
        tile.addView(icon, new LinearLayout.LayoutParams(size, size));
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(2);
        label.setEllipsize(TextUtils.TruncateAt.END);
        tile.addView(label);

        tile.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent launch = pm.getLaunchIntentForPackage(e.pkg);
                if (launch == null) {
                    Toast.makeText(MainActivity.this, "التطبيق لم يعد متاحاً", Toast.LENGTH_SHORT).show();
                    return;
                }
                try { startActivity(launch); }
                catch (Exception ex) { Toast.makeText(MainActivity.this, "تعذر فتح التطبيق", Toast.LENGTH_SHORT).show(); }
            }
        });
        tile.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                Set<String> set = favorites();
                if (set.contains(e.pkg)) {
                    set.remove(e.pkg);
                    Toast.makeText(MainActivity.this, "أزيل من المفضلة", Toast.LENGTH_SHORT).show();
                } else {
                    set.add(e.pkg);
                    Toast.makeText(MainActivity.this, "أضيف إلى المفضلة", Toast.LENGTH_SHORT).show();
                }
                saveFavorites(set);
                renderApps();
                return true;
            }
        });
        tile.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean hasFocus) {
                v.setBackground(shape(hasFocus ? focusColor() : cardColor(), 14, hasFocus));
                label.setTextColor(hasFocus ? accent() : textMain());
            }
        });
        grid.addView(tile);
        return tile;
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            new AlertDialog.Builder(this).setTitle("تيلينوفا TV")
                .setItems(new String[]{"الإعدادات", "اختيار الخلفية", "تبديل وضع التركيز", "حول التطبيق"},
                    new android.content.DialogInterface.OnClickListener() {
                        @Override public void onClick(android.content.DialogInterface d, int w) {
                            if (w == 0) openSettings();
                            else if (w == 1) pickWallpaper();
                            else if (w == 2) toggleFocusMode();
                            else new AlertDialog.Builder(MainActivity.this)
                                .setMessage("تيلينوفا TV — واجهة رئيسية تجريبية لأندرويد 8.0 وما بعده.")
                                .setPositiveButton("حسناً", null).show();
                        }
                    }).show();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
